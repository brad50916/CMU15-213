//2
long copyLSB(long);
long test_copyLSB(long);
long allOddBits(long);
long test_allOddBits(long);
long isNotEqual(long, long);
long test_isNotEqual(long, long);
long dividePower2(long, long);
long test_dividePower2(long, long);
//3
long remainderPower2(long, long);
long test_remainderPower2(long, long);
long rotateLeft(long, long);
long test_rotateLeft(long, long);
long bitMask(long, long);
long test_bitMask(long, long);
long isPower2(long);
long test_isPower2(long);
//4
long allAsciiDigits(long);
long test_allAsciiDigits(long);
long trueThreeFourths(long);
long test_trueThreeFourths(long);
long bitCount(long);
long test_bitCount(long);
